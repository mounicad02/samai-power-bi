Task2_HR_Analytics

Required dashboard objectives and deliverables.
Add dataset, Power BI (.pbix) file, screenshots/reports here.