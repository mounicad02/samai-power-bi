Task1_Customer_Churn_Analysis

Required dashboard objectives and deliverables.
Add dataset, Power BI (.pbix) file, screenshots/reports here.