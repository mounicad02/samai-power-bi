Task3_Education_Performance_Dashboard

Required dashboard objectives and deliverables.
Add dataset, Power BI (.pbix) file, screenshots/reports here.